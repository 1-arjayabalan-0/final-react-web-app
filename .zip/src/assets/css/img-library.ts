import Appslogo from '../images/app-logo.png';
import AppslogoBig from '../images/app-logo-big.png';
import Brandlogo from '../images/brand-logo.png';
import AvatarImg from '../images/avatar.png';
import LoginBg from '../images/login-bg.png';

import BackImg from '../images/ico-back.png'
import VisitorImg from '../images/ico-visitor.png'
import ContractorImg from '../images/ico-contractor.png'
import InterviewImg from '../images/ico-interview.png'
import InvoiceImg from '../images/ico-invoice.png'
import VehicleTripImg from '../images/ico-vehicle-trip.png'
import DeliveryChallanImg from '../images/ico-delivery-challan.png'

export { Appslogo,AppslogoBig,LoginBg,Brandlogo,AvatarImg,BackImg,VisitorImg,ContractorImg,InterviewImg,InvoiceImg,VehicleTripImg,DeliveryChallanImg };
