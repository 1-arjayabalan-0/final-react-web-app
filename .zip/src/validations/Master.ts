import { object, string, number, date, InferType } from "yup";

//Login
export const AuthValidationScheam = object({
  UserName: string().required(),
  PassWord: string().required(),
});

// State
export const StateValidationSchema = object({
  StateName: string().min(2, "Too Short").required(),
  Status: number().required().positive().integer(),
  CountryId: number().required(),
});
