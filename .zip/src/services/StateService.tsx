import api from "../utils/api";

export const fetchStates = (data) => {
  return api.post("/State/SearchInitialize", data);
};
export const createInit = (data) => {
  return api.post("/State/CreateInitialize", data);
};

export const createState = (data) => {
  return api.post("/State/Create", data);
};
export const updateState = (data) => {
  return api.post("/State/Update", data);
};
