import { Layouts } from "../layouts/Layout";
import { Pages } from "./Pages";

export const PageRoutes = [
  {
    path: "/",
    Component: Pages.vStatePage,
    Layout: Layouts.AppLayout,
  },
  {
    path: "/Login",
    Component: Pages.LoginPage,
    exact: true,
  },
  {
    path: "/State",
    Component: Pages.AdminPage,
    Private: false,
    Layout: Layouts.AppLayout,
    modules: [
      {
        path: "/vState",
        Component: Pages.vStatePage,
        exact: true,
      },
      {
        path: "/cState",
        Component: Pages.cStatePage,
        exact: true,
      },
    ],
  },
  {
    path: "",
    Component: Pages.NotFound,
  },
];
