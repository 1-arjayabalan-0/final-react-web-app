import React, { useRef } from "react";
import { useSelector, useDispatch } from "react-redux";
import { Toast } from "primereact/toast";
import { hideToast } from "../redux/slices/common/alertsSlice";

export const getSeverity = (status) => {
  switch (status) {
    case "Active":
      return "success";
    case "Inactive":
      return "warning";
    case "OUTOFSTOCK":
      return "danger";

    default:
      return null;
  }
};

const ToastComponent = () => {
  const dispatch = useDispatch();

  const { severity, summary, detail, life } = useSelector(
    (state: any) => state.alerts
  );

  const toastRef = useRef(null);

  const onHide = () => {
    dispatch(hideToast());
  };

  return (
    <Toast
      ref={toastRef}
      position="top-right"
      onHide={onHide}
      {...{ severity, summary, detail, life }}
    />
  );
};

export default ToastComponent;
