import React, { useState, useRef, useEffect } from "react";
import { useHistory } from "react-router-dom";
import { Button } from "primereact/button";
import { Rating } from "primereact/rating";
import { InputText } from "primereact/inputtext";
import { useDispatch, useSelector } from "react-redux";

import AppTable from "components/AppTable";
import PageHeader from "components/PageHeader";
import { createInit, fetchStates } from "redux/slices/master/state/stateSlice";
import FormFields from "components/FormFields";
import { Formik, useFormik } from "formik";
import { StateValidationSchema } from "validations/Master";
import { Dropdown } from "assets/css/prime-library";

const CState = () => {
  const route = useHistory();
  const dispatch: any = useDispatch();

  useEffect(() => {
    console.log(createOrEditState);
    if (createOrEditState.createEditData != null) {
      if (createOrEditState.isCreate == false) {
        const data = {
          Stateid: createOrEditState.createEditData.StateId,
        };
        dispatch(createInit(data));
        console.log("asdasd");
      } else {
        const data = {
          Stateid: 0,
        };
        dispatch(createInit(data));
        console.log("aretert");
      }
    }
  }, []);

  const allStates = useSelector((state: any) => state.states.states);
  const createOrEditState = useSelector((state: any) => state.states);
  const loading = useSelector((state: any) => state.states.loading);
  const error = useSelector((state: any) => state.states.error);

  const { countryList } = useSelector((state: any) => state.states);
  const { statusList } = useSelector((state: any) => state.states);

  const formik: any = useFormik({
    initialValues: {
      // CountryName:
      //   createOrEditState != null
      //     ? createOrEditState.createEditData.CountryId
      //     : ""
      // StateName:
      //   createOrEditState != null
      //     ? createOrEditState.createEditData.StateName
      //     : "",
      // Status:
      //   createOrEditState.createEditData != null
      //     ? createOrEditState.createEditData.Status == "Active"
      //       ? 1
      //       : 2
      //     : "",
    },
    validationSchema: StateValidationSchema,
    onSubmit: (values) => {
      console.log(values);
    },
  });

  useEffect(() => {
    console.log(createOrEditState);

    console.log(countryList);
  });

  const handleSelect = (e) => {
    console.log(e.target.value);
  };

  return (
    <>
      <Formik
        initialValues={formik.initialValues}
        validationSchema={formik.validationSchema}
        onSubmit={formik.handleSubmit}
      >
        <div className="page-container">
          <div className="inner-page-container">
            <div className="page-title">
              <div className="grid grid-nogutter">
                <div className="md:col-6">
                  <h1>State</h1>
                </div>
                <div className="md:col-6 text-right">
                  <div className="action-btn">
                    <>
                      <Button
                        label=""
                        title="Save"
                        icon="pi pi-eye"
                        className="text-center"
                        type="submit"
                        onClick={() => formik.handleSubmit()}
                      />
                      <Button
                        label=""
                        severity="danger"
                        icon="pi pi-trash"
                        title="Clear"
                        className="text-center"
                      />
                    </>
                    {/* <a
                    href="/vState"
                    title="Back to View"
                    className="p-button p-button-success text-center"
                  >
                    <i className="pi pi-search"></i>
                  </a> */}
                    <Button
                      label=""
                      icon="pi pi-search"
                      title="Add"
                      className="p-button p-button-success text-center"
                      onClick={() => {
                        route.push("/State/vState");
                      }}
                    />
                  </div>
                </div>
              </div>
            </div>

            <div className="form-container scroll-y">
              <form>
                <div className="white">
                  <div className="widget-body">
                    <div className="normal-table">
                      <div className="grid">
                        {!loading ? (
                          <>
                            {/* <div className="col-12 md:col-3">
                              <label className="form-label">
                                Country Name
                                <span className="hlt-txt">*</span>
                              </label>
                              <Dropdown
                                options={countryList}
                                optionLabel={"countryName"}
                                optionValue={"countryId"}
                                placeholder={"Country Name"}
                                className="w-full"
                                onBlur={formik.handleBlur}
                                onChange={(e) => handleSelect}
                              />
                              <small className="p-error">
                                {formik.touched["countryName"] &&
                                  formik.errors["countryName"]}
                              </small>
                            </div> */}

                            <Dropdown
                              type={"select"}
                              name={"CountryName"}
                              options={countryList}
                              required={true}
                              optionLabel={"countryName"}
                              optionValue={"countryId"}
                            />

                            <FormFields
                              type={"select"}
                              name={"CountryName"}
                              label={"Country Name"}
                              options={countryList}
                              show={true}
                              required={true}
                              disable={false}
                              optionLabel={"CountryName"}
                              optionValue={"CountryId"}
                              formik={formik}
                            />
                            <FormFields
                              type={"text"}
                              name={"StateCode"}
                              label={"State Code"}
                              options={""}
                              show={true}
                              required={true}
                              disable={false}
                              optionLabel={""}
                              optionValue={""}
                              handleSelect={""}
                              formik={formik}
                            />
                            <FormFields
                              type={"text"}
                              name={"StateName"}
                              label={"State Name"}
                              options={""}
                              show={true}
                              required={true}
                              disable={false}
                              optionLabel={""}
                              optionValue={""}
                              handleSelect={""}
                              formik={formik}
                            />
                            <div className="col-12 md:col-3">
                              <label className="form-label">
                                Status
                                <span className="hlt-txt">*</span>
                              </label>
                              <Dropdown
                                options={statusList}
                                optionLabel={"metaSubDescription"}
                                optionValue={"metaSubId"}
                                placeholder={"Status"}
                                className="w-full"
                                onBlur={formik.handleBlur}
                                onChange={(e) => handleSelect}
                              />
                              <small className="p-error">
                                {formik.touched["metaSubDescription"] &&
                                  formik.errors["metaSubDescription"]}
                              </small>
                            </div>
                          </>
                        ) : (
                          "loading"
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              </form>
            </div>
          </div>
        </div>
      </Formik>
    </>
  );
};

export default CState;
