import { combineReducers } from "redux";
import alertsSlice from "../slices/common/alertsSlice";
import stateSlice from "../slices/master/state/stateSlice";
import authSlice from "../slices/common/authSlice";

const RootReducer = combineReducers({
  states: stateSlice,
  auth: authSlice,
  alerts: alertsSlice,
});

export default RootReducer;
