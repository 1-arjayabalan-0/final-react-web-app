import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";
import * as StateService from "../../../../services/StateService";

export const fetchStates = createAsyncThunk(
  "state/fetchStates",
  async (data: any, { rejectWithValue }) => {
    try {
      const states = await StateService.fetchStates(data);
      
      return states.data;
    } catch (err) {
      return rejectWithValue(err.message);
    }
  }
);

export const createInit = createAsyncThunk(
  "state/createInit",
  async (data: any, thunkAPI) => {
    try {
      const states = await StateService.createInit(data);
      return states.data;
    } catch (err) {
      return thunkAPI.rejectWithValue(err.message);
    }
  }
);

const initialState = {
  states: [],
  isCreate: false,
  createEditData: null,
  loading: false,
  error: null,
  statusList: [],
  countryList: [],
  hdrTable: [],
};

const stateSlice = createSlice({
  name: "state",
  initialState,
  reducers: {
    createOrEdit: (state: any, action) => {
      state.createEditData = action.payload;
      state.isCreate = action.payload != null ? false : true;
    },
  },
  extraReducers: (builder) => {
    builder
      .addCase(fetchStates.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(fetchStates.fulfilled, (state, action: any) => {
        state.loading = false;
        state.states = action.payload.StateList;
      })
      .addCase(fetchStates.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload;
      })
      .addCase(createInit.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(createInit.fulfilled, (state, action) => {
        state.loading = false;
        state.error = "";
        state.statusList = action.payload.StatusList;
        state.countryList = action.payload.CountryList;
        state.hdrTable = action.payload.HdrTable;
      })
      .addCase(createInit.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload;
      });
  },
});

export const { createOrEdit } = stateSlice.actions;

export default stateSlice.reducer;
