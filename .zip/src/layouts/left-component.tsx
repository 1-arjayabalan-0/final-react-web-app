import { PanelMenu, Tooltip } from "../assets/css/prime-library";
import { Link } from "react-router-dom";

const LeftComponent = () => {
  let menuDashboard = [{ label: "Dashboard", url: "vDashboard" }];
  let menuMaster = [{ label: "State", url: "vState" }];
  let menuEntry = [{ label: "Visitor Management", url: "vVisitorManagement" }];
  let mainMenu = [
    {
      id: 1,
      relLink: "dashboard",
      menuTitle: "MIS and Dashboard",
      menuIcon: "las la-chart-bar",
    },
    {
      id: 2,
      relLink: "masters",
      menuTitle: "Masters",
      menuIcon: "las la-tools",
    },
    {
      id: 3,
      relLink: "gateentry",
      menuTitle: "Gate Entry",
      menuIcon: "las la-id-card",
    },
  ];

  return (
    <div>
      <div className="apps-left bg-shadow">
        <div className="sidebar overflow-y">
          <div className="menu-tabs" rel="main-menu">
            <Tooltip target=".menu-tabs a" />
            {mainMenu.map((menuLink) => (
              // <Link
              //   key={menuLink.id}
              //   to={menuLink.relLink}
              //   data-pr-tooltip={menuLink.menuTitle}
              //   data-pr-position="right"
              // >
              //   <i className={menuLink.menuIcon}></i>
              // </Link>
              <Link
                key={menuLink.id}
                rel={menuLink.relLink}
                data-pr-tooltip={menuLink.menuTitle}
                data-pr-position="right"
              >
                <i className={menuLink.menuIcon}></i>
              </Link>
            ))}
          </div>
        </div>
      </div>
      <div className="apps-center bg-shadow">
        <div className="main-menu scroll-y">
          <div className="menu-tabs-container dashboard">
            <h5>Dashboard</h5>
            <PanelMenu className="left-menu" model={menuDashboard} />
          </div>
          <div className="menu-tabs-container masters">
            <h5>Masters</h5>
            <PanelMenu className="left-menu" model={menuMaster} />
          </div>
          <div className="menu-tabs-container gateentry">
            <h5>Visitor Entry</h5>
            <PanelMenu className="left-menu" model={menuEntry} />
          </div>
        </div>
      </div>
    </div>
  );
};

export default LeftComponent;
